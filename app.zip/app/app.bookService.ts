import {Injectable} from '@angular/core'
import {HttpClient} from '@angular/common/http'

@Injectable({
    providedIn:'root'
})

export class BookService{
    constructor(private httpdata:HttpClient){}

    addBook(book:any){
        console.log(book.bookId);
        let input=new FormData();
        input.append("bookTitle",book.bookTitle);
        input.append("bookAuthor",book.bookAuthor);
        input.append("bookDesc",book.bookDesc);
        input.append("bookISBNo",book.bookISBNo);
        input.append("bookPrice",book.bookPrice);
        input.append("bookPublishDate",book.bookPublishDate);
        input.append("bookQuantity",book.bookQuantity);
        input.append("bookCategory",book.bookCategory);
        return this.httpdata.post("http://localhost:8099/acceptBookDetails",input);
    }

    getAllBookDetails(){
        return this.httpdata.get("http://localhost:8099/getAllBookDetails");
    }

    deleteBookDetails(data:any){
        console.log(data);
        return this.httpdata.delete("http://localhost:8099/deleteBook/"+data);
    }

    // updateCustomerDetails(custId:any,customer:any){
        
    // }
}