import {Component,OnInit} from '@angular/core';

@Component({
    selector:'functions',
    templateUrl:'app.bookstore.functions.html'
})

export class MainBookStore{}