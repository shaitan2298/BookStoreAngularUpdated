import {Component,OnInit} from '@angular/core';
import {CustomerService} from './app.customerService';

@Component({
    selector:'customer-func',
    templateUrl:'Customer.html'
})

export class CustomerMenuComponent{
    constructor(private custservice:CustomerService){}
    customer:any=[];
    customerone:any={};
    addCustomer():any{
        this.custservice.addCustomer(this.customer).subscribe((customer)=>this.customer.customerId);
        alert("Sucessfully added and customerId is"+this.customer.customerId);
    }

    getAllCustomerDetails():any{
        this.custservice.getAllCustomerDetails().subscribe((data:any)=>this.customer=data)
    }

    deleteCustomer(i:number):any{
        this.custservice.deleteCustomerDetails(i).subscribe();
        alert("Customer is deleted");
    }
}