﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, FormBuilder, FormGroup }from '@angular/forms';
import { CustomerMenuComponent} from './app.customercomponent';
import { BookMenuComponent} from './app.bookComponent';
import {Routes,RouterModule} from '@angular/router';

const router:Routes=[
    {path:'cust',component:CustomerMenuComponent},
     {path:'book',component:BookMenuComponent}
]

@NgModule({
    imports: [
        BrowserModule,HttpClientModule,FormsModule,RouterModule.forRoot(router)
        
    ],
    declarations: [
        AppComponent,CustomerMenuComponent,BookMenuComponent
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }