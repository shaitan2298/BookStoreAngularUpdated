// import {Component,OnInit} from '@angular/core';
// import {CustomerService} from './app.customerService';

// @Component({
//     selector:'customerMenuPage',
//     templateUrl:'Customer.html'
// })

// export class CustomerFunctionComponent{

// }