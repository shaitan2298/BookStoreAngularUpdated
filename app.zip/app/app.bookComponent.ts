import {Component,OnInit} from '@angular/core';
import {BookService} from './app.bookService';

@Component({
    selector:'book-func',
    templateUrl:'book.html'
})

export class BookMenuComponent{
    constructor(private bookservice:BookService){}
    book:any=[];
    bookone:any={};
    addBook():any{
        this.bookservice.addBook(this.book).subscribe((book)=>this.book.bookId);
        alert("Sucessfully added and bookId is"+this.book.bookId);
    }

    getAllBookDetails():any{
        this.bookservice.getAllBookDetails().subscribe((data:any)=>this.book=data)
    }

    deleteBook(i:number):any{
        this.bookservice.deleteBookDetails(i).subscribe();
        alert("Book is deleted");
    }
}